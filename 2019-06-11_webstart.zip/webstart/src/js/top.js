$(document).ready(function(){
        $('.top_arrow').click(function(){
        $("html, body").animate({ scrollTop: 0 }, 600);
        return false;
    });
  
});